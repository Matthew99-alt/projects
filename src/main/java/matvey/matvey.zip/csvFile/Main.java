package matvey.csvFile;

public class Main {

    public static void main(String[] args) {
        AppData appa = new AppData(new String[3], new int[3][3]);
        appa.writeDownAndRead();
    }

}
