package matvey.csvFile;

import java.io.*;
import java.util.Arrays;
import java.util.Iterator;
import java.util.StringTokenizer;

public class AppData {

    private String[] header;
    private final int[][] data;

    AppData(String[] header, int[][] data) {
        this.header = header;
        this.data = data;
    }

    public void writeDownAndRead() {
        File file = fillAndSaveFile();
        readFile(file);
    }

    private void readFile(File file) {
        //чтение
        try (BufferedReader in = new BufferedReader(new FileReader(file))) {
            this.header = new String[]{Arrays.toString(in.readLine().split(";"))};
            String curLine;
            String[] lines;

            for (String s : this.header) {
                System.out.println(s);
            }

            while ((curLine = in.readLine()) != null) {
                lines = curLine.trim().split(";");
                for (int y = 0; y < lines.length; y++) {
                    for (int x = 0; x < lines.length; x++) {
                        this.data[x][y] = Integer.parseInt(lines[x]);
                    }
                }
                ;
            }

            for (int[] datum : this.data) {
                for (int j = 0; j < this.data[0].length; j++) {
                    System.out.print(datum[j] + ";");
                }
                System.out.println();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private File fillAndSaveFile() {
        File file = new File("AppData.csv");
        //запись в файл

        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(file))) {
            //пишем заголовки, устраняем скобки с помощью регулярных выражений
            for (int j = 0; j < this.data[0].length; j++) {
                out.write((("Value " + j) + ((j == this.data.length - 1)
                        ? System.getProperty("line.separator") : ";")).getBytes());
            }
            //пишем числа

            for (int[] datum : this.data) {
                for (int j = 0; j < datum.length; j++) {
                    out.write((100 + ((j == datum.length - 1) ?
                            System.getProperty("line.separator") : ";")).getBytes());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return file;
    }
}