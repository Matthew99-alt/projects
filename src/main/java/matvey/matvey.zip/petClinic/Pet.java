package matvey.petClinic;

import java.util.List;
import java.util.Objects;

abstract class Pet {
    private final String nickname;
    private final int age;
    private final String ownerName;
    private final String breed;
    private final List<String> color;

    public Pet(String nickname, int age, String ownerName, String breed, List<String> color) {
        this.nickname = nickname;
        this.age = age;
        this.ownerName = ownerName;
        this.breed = breed;
        this.color = color;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || obj.getClass() != this.getClass())
            return false;
        if (this.age != ((Pet) obj).age) return false;
        if (!this.color.equals(((Pet) obj).color)) return false;
        if (!Objects.equals(this.nickname, ((Pet) obj).nickname)) return false;
        if (!Objects.equals(this.breed, ((Pet) obj).breed)) return false;
        if (!Objects.equals(this.ownerName, ((Pet) obj).ownerName)) return false;
        else {
            return true;
        }
    }

    @Override
    public int hashCode() {
        return 31 * this.nickname.length() +
                this.age + this.ownerName.length()
                + color.size();
    }
}
