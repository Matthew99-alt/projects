package matvey.petClinic;

import java.util.*;

public class Clinic {

    private final HashSet<Pet> Animals;

    public Clinic(HashSet<Pet> Animals) {
        this.Animals = Animals;
    }

    public void addAnimal(Pet pet) {
        if (!this.check(pet)) {
            this.Animals.add(pet);
            System.out.println("Питомец добавлен");
        } else {
            System.out.println("Данный питомец уже зарегистрирован в поликлинике");
        }
    }

    public boolean check(Pet pet) {
        for (Pet i : this.Animals) {
            if (i.hashCode() == pet.hashCode()) {
                return i.equals(pet);
            }
        }
        return false;
    }
}
