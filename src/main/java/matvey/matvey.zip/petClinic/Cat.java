package matvey.petClinic;

import java.util.List;

public class Cat extends Pet {
    public Cat(String nickname, int age, String ownerName, String breed, List<String> color) {
        super(nickname, age, ownerName, breed, color);
    }
}
