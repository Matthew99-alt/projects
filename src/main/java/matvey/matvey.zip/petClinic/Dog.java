package matvey.petClinic;

import java.util.List;

public class Dog extends Pet{
    public Dog(String nickname, int age, String ownerName, String breed, List<String> color) {
        super(nickname, age, ownerName, breed, color);
    }
}
